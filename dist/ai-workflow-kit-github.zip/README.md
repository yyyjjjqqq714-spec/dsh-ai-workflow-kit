# AI 工作流 · 视频风格库

340 个代码动画风格的提示词、8 个可复用提示词、5 个代码模板，附带静态浏览站。

在线预览：部署到 GitHub Pages 后访问 `https://<用户名>.github.io/<仓库名>/`

![预览](site/stills/S1-A3.jpg)

## 内容

| 类别 | 数量 | 说明 |
|---|---|---|
| 视频风格 | 340 | 每个都有完整提示词 + 示意图（193 张原作者参考图 + 147 张按提示词渲染的示意帧） |
| 提示词 | 8 | MV 分镜、风格改写、代码模板生成、短视频脚本等 |
| 代码模板 | 5 | Fastify / React / Zod / FastAPI / Python CLI |

其中 **70 个原本只有一句话的风格**（S3 卡通 38、S10 中国风 13、S2 版式 11、S5 动态 8）已补全为可执行的完整提示词，放在 `content/styles/_patched/`，不改动原始库。

## 目录结构

```
.
├── site/                  # 静态站点（GitHub Pages 部署目录）
│   ├── index.html
│   ├── data.js            # 内联数据（340 条 md + 元数据）
│   └── stills/            # 340 张示意图
├── content/               # 源数据
│   ├── styles/_index.json # 340 条索引
│   ├── styles/_patched/   # 70 条补全版提示词（覆盖层）
│   ├── styles/_generated/ # 147 张渲染示意图
│   ├── prompts/           # 8 个提示词
│   └── templates/         # 5 个代码模板
├── tools/                 # 构建脚本（索引 / 站点 / 导出）
├── docs/api-exports.md    # 数据接口说明
└── .github/workflows/     # 自动部署 Pages
```

## 部署到 GitHub Pages

1. 在 GitHub 新建仓库（不要勾选 README）
2. 把本目录内容推上去：

```bash
git init
git add .
git commit -m "init"
git branch -M main
git remote add origin https://github.com/<用户名>/<仓库名>.git
git push -u origin main
```

3. 仓库 **Settings → Pages → Source** 选 **GitHub Actions**
4. 等 1-2 分钟，访问 `https://<用户名>.github.io/<仓库名>/`

workflow 已配好，之后每次 push 自动更新。

## 部署到 Netlify（不注册也能先看）

把 zip 拖到 https://app.netlify.com/drop 即可，注册后可长期保留。

## 在其他程序里调用

### 读文件

```python
import json
styles = json.load(open('site/data.js')[0:0])  # 或用 content/styles/_index.json
```

更简单：直接读 `content/styles/_index.json` + `content/styles/_patched/<id>.md`。

### 生成完整数据包

```bash
node tools/export-bundle.mjs   # 输出 content/exports/（JSON + md + jpg）
node tools/build-site.mjs      # 重建站点
```

详见 [docs/api-exports.md](docs/api-exports.md)。

## 作为 DSH 插件使用

本仓库的 `plugin/` 目录是一个 DeepSeek Harness 插件（侧边栏面板 + `/awkit` 命令），安装方式见原项目。

## 许可证

- 视频风格提示词来自公开代码动画风格库，仅供学习与个人创作
- 193 张参考图版权归原作者
- 147 张示意图、提示词补全、模板、站点代码：MIT
