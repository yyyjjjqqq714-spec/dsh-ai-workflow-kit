@echo off
chcp 65001 >nul
setlocal

echo ========================================
echo   AI 工作流视频风格库 - GitHub 推送
echo ========================================
echo.

if "%~1"=="" (
  echo 用法: push-github.bat 你的GitHub用户名 仓库名
  echo.
  echo 例如: push-github.bat zhangsan ai-workflow-kit
  echo.
  echo 前提:
  echo   1. 已在这个账号下建好空仓库 ^(不要勾选 README^.gitignore^)
  echo   2. 本机 git 已配置 GitHub 凭据 ^(首次 push 会弹窗登录^)
  echo.
  pause
  exit /b 1
)

set GH_USER=%~1
set GH_REPO=%~2
set REPO_URL=https://github.com/%GH_USER%/%GH_REPO%.git

echo 目标仓库: %REPO_URL%
echo.

cd /d "%~dp0"

git remote remove origin 2>nul
git remote add origin %REPO_URL%
git branch -M main

echo [1/2] 推送中（首次会让你登录 GitHub）...
git push -u origin main
if errorlevel 1 (
  echo.
  echo 推送失败。常见原因:
  echo   - 仓库还没建 ^(先去 https://github.com/new 建一个空仓库^)
  echo   - 用户名或仓库名写错
  echo   - 没登录 GitHub ^(会弹窗^)
  echo.
  pause
  exit /b 1
)

echo.
echo [2/2] 推送成功！
echo.
echo 接下来手动开启 Pages ^(只需一次^):
echo   打开 %REPO_URL%/settings/pages
echo   Source 选 "GitHub Actions"
echo.
echo 等 1-2 分钟后访问:
echo   https://%GH_USER%.github.io/%GH_REPO%/
echo.
pause
